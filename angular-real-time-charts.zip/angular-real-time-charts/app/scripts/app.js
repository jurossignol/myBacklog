'use strict';

angular.module('app', ['ngRoute', 'app.service', 'app.controller', 'angularCharts']);

angular.module('app').config(function ($routeProvider, webSocketProvider) {
  webSocketProvider.setWebSocketURL('ws://' + window.location.host + '/sockjs/websocket');

  $routeProvider
    .when('/', {
      templateUrl: 'views/main.html',
      controller: 'MainCtrl'
    })
    .otherwise({
      redirectTo: '/'
    });
});

