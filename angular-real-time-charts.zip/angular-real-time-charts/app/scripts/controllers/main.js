'use strict';

angular.module('app.controller', []);

angular.module('app.controller')
  .controller('MainCtrl', function ($scope, webSocket) {
	  
	  $scope.config = {
			    title: 'Products',
			    tooltips: true,
			    labels: false,
			    mouseover: function() {},
			    mouseout: function() {},
			    click: function() {},
			    legend: {
			      display: true,
			      //could be 'left, right'
			      position: 'right'
			    }
			  };

			  $scope.data = {
			    series: ['Sales', 'Income', 'Expense', 'Laptops', 'Keyboards'],
			    data: [{
			      x: "Laptops",
			      y: [100, 500, 0],
			      tooltip: ["this is tooltip", "mytest", "todo"]
			    }, {
			      x: "Desktops",
			      y: [300, 100, 100],
			      tooltip: ["<b>this is</b> <br>tooltip", "mytest", "todo"]
			    }, {
			      x: "Mobiles",
			      y: [351]
			    }, {
			      x: "Tablets",
			      y: [54, 0, 879]
			    }]
			  };
	  
	  
//    $scope.gaugeValue = 0;
//
//    var items = [];
//
//    webSocket.subscribe(function (item) {
//      items.push(item);
//
//      if (items.length > 40) {
//        items.shift();
//      }
//
//      $scope.chart = {
//        data: items,
//        max: 30
//      };
//
//      $scope.gaugeValue = item.value;
//      $scope.$apply();
//    });
  });
